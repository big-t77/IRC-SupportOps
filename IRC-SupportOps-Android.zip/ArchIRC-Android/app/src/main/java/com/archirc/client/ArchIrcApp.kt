package com.archirc.client

import android.app.Application
import timber.log.Timber

class ArchIrcApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}

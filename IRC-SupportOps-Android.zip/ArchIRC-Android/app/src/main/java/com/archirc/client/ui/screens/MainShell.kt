package com.archirc.client.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archirc.client.ui.theme.ArchBlue

enum class MainTab(val label: String, val icon: ImageVector) {
    Networks("Networks", Icons.Outlined.Public),
    Channels("Channels", Icons.Outlined.Tag),
    Users("Users", Icons.Outlined.People),
    Tools("Tools", Icons.Outlined.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainShell(
    modifier: Modifier = Modifier,
    darkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Networks) }

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Top bar — matches mockup header
        TopAppBar(
            title = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "IRC SupportOps",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Text(
                        "IRC Support & Operator Console",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            actions = {
                IconButton(onClick = onToggleTheme) {
                    Icon(
                        if (darkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                        contentDescription = "Toggle theme"
                    )
                }
                IconButton(onClick = { /* menu */ }) {
                    Icon(Icons.Outlined.MoreVert, contentDescription = "More")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        // Tab row — Networks | Channels | Users | Tools
        TabRow(
            selectedTabIndex = tab.ordinal,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = ArchBlue
        ) {
            MainTab.entries.forEach { t ->
                Tab(
                    selected = tab == t,
                    onClick = { tab = t },
                    text = {
                        Text(
                            t.label,
                            fontSize = 13.sp,
                            fontWeight = if (tab == t) FontWeight.SemiBold else FontWeight.Normal
                        )
                    },
                    icon = {
                        Icon(t.icon, contentDescription = t.label, modifier = Modifier.size(20.dp))
                    }
                )
            }
        }

        // Content
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                MainTab.Networks -> NetworksScreen()
                MainTab.Channels -> ChannelsScreen()
                MainTab.Users -> UsersScreen()
                MainTab.Tools -> ToolsScreen()
            }
        }
    }
}

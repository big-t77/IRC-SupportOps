package com.archirc.client.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ArchBlue = Color(0xFF1793D1)
val ArchBlueDark = Color(0xFF0D6FA0)

val DarkBg = Color(0xFF0E1116)
val DarkSurface = Color(0xFF161A21)
val DarkSurfaceVariant = Color(0xFF1E2430)
val DarkOnBg = Color(0xFFE8EAED)
val DarkMuted = Color(0xFF9AA3AD)
val DarkLine = Color(0xFF2A3140)

val LightBg = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF1F6)
val LightOnBg = Color(0xFF1A1D24)
val LightMuted = Color(0xFF5C6570)
val LightLine = Color(0xFFD8DEE8)

private val DarkScheme = darkColorScheme(
    primary = ArchBlue,
    onPrimary = Color.White,
    secondary = ArchBlue,
    background = DarkBg,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    onBackground = DarkOnBg,
    onSurface = DarkOnBg,
    onSurfaceVariant = DarkMuted,
    outline = DarkLine,
    error = Color(0xFFE06C75)
)

private val LightScheme = lightColorScheme(
    primary = ArchBlue,
    onPrimary = Color.White,
    secondary = ArchBlueDark,
    background = LightBg,
    surface = LightSurface,
    surfaceVariant = LightSurfaceVariant,
    onBackground = LightOnBg,
    onSurface = LightOnBg,
    onSurfaceVariant = LightMuted,
    outline = LightLine,
    error = Color(0xFFC45C3E)
)

@Composable
fun ArchIrcTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        content = content
    )
}

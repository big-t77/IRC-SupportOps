package com.archirc.client.core

import com.archirc.client.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Low-level async IRC engine.
 *
 * Uses plain SSLSocket + coroutines (no heavy third-party IRC lib).
 * Supports TLS, basic IRCv3 CAP, SASL PLAIN, and clean reconnection.
 *
 * Bouncers (ZNC / soju) work over the same TLS socket — no SSH tunnel required
 * as long as the bouncer is reachable on a public port with a valid cert
 * (or you trust the cert / pin it later).
 */
class IrcEngine(
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(ConnectionState(""))
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<IrcMessage>(extraBufferCapacity = 128)
    val messages: SharedFlow<IrcMessage> = _messages.asSharedFlow()

    private val _rawLines = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val rawLines: SharedFlow<String> = _rawLines.asSharedFlow()

    private var socket: Socket? = null
    private var writer: BufferedWriter? = null
    private var readerJob: Job? = null
    private var pingJob: Job? = null
    private val running = AtomicBoolean(false)

    private var currentProfile: NetworkProfile? = null
    private var registered = false
    private val pendingCaps = mutableSetOf<String>()
    private var saslInProgress = false

    suspend fun connect(profile: NetworkProfile) {
        if (running.get()) disconnect()
        currentProfile = profile
        _state.value = ConnectionState(profile.id, ConnStatus.CONNECTING)
        registered = false
        pendingCaps.clear()
        saslInProgress = false

        try {
            val sock = withContext(Dispatchers.IO) {
                createSocket(profile.host, profile.port, profile.useTls)
            }
            socket = sock
            writer = BufferedWriter(OutputStreamWriter(sock.getOutputStream(), Charsets.UTF_8))
            running.set(true)

            // Start reader
            readerJob = scope.launch(Dispatchers.IO) {
                val reader = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.UTF_8))
                try {
                    while (running.get() && !sock.isClosed) {
                        val line = reader.readLine() ?: break
                        handleIncoming(line)
                    }
                } catch (e: Exception) {
                    if (running.get()) {
                        Timber.e(e, "Reader died")
                        _state.value = _state.value.copy(
                            status = ConnStatus.RECONNECTING,
                            lastError = e.message
                        )
                    }
                } finally {
                    if (running.get()) scheduleReconnect()
                }
            }

            // IRCv3 CAP negotiation first
            sendRaw("CAP LS 302")
            // Then registration sequence continues after CAP END

            // Keepalive
            pingJob = scope.launch {
                while (running.get()) {
                    delay(60_000)
                    if (registered) sendRaw("PING :archirc")
                }
            }

        } catch (e: Exception) {
            Timber.e(e, "Connect failed")
            _state.value = ConnectionState(profile.id, ConnStatus.DISCONNECTED, e.message)
            running.set(false)
        }
    }

    private fun createSocket(host: String, port: Int, tls: Boolean): Socket {
        return if (tls) {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, null, SecureRandom())
            val factory = ctx.socketFactory as SSLSocketFactory
            val ssl = factory.createSocket() as SSLSocket
            ssl.connect(InetSocketAddress(host, port), 15_000)
            ssl.startHandshake()
            // Optional: enable modern protocols only
            ssl.enabledProtocols = arrayOf("TLSv1.3", "TLSv1.2")
            ssl
        } else {
            val s = Socket()
            s.connect(InetSocketAddress(host, port), 15_000)
            s
        }
    }

    private suspend fun handleIncoming(raw: String) {
        _rawLines.emit(raw)
        Timber.d("<< %s", raw)

        when {
            raw.startsWith("PING ") -> {
                val token = raw.substringAfter("PING ")
                sendRaw("PONG $token")
            }
            raw.contains(" CAP ") -> handleCap(raw)
            raw.startsWith("AUTHENTICATE ") || raw.contains(" SASL ") -> handleSasl(raw)
            // Numeric replies
            else -> {
                val parsed = parseLine(raw)
                if (parsed != null) {
                    when (parsed.command) {
                        "001" -> { // Welcome
                            registered = true
                            _state.value = _state.value.copy(
                                status = ConnStatus.CONNECTED,
                                serverName = parsed.params.getOrNull(1),
                                myNick = currentProfile?.nick
                            )
                            // Auto-join channels
                            currentProfile?.channels?.forEach { ch ->
                                sendRaw("JOIN $ch")
                            }
                        }
                        "433" -> { // Nick in use
                            val alt = (currentProfile?.nick ?: "user") + "_"
                            sendRaw("NICK $alt")
                        }
                        "PRIVMSG", "NOTICE" -> emitMessage(parsed)
                        "JOIN", "PART", "QUIT", "MODE", "TOPIC", "NICK" -> emitSystem(parsed)
                        else -> { /* ignore for now */ }
                    }
                }
            }
        }
    }

    private fun handleCap(raw: String) {
        // Very simplified CAP handling
        if (raw.contains("LS") || raw.contains("ACK") || raw.contains("NAK")) {
            // Request useful caps
            val wanted = listOf(
                "multi-prefix", "extended-join", "account-notify",
                "message-tags", "server-time", "away-notify"
            )
            // In real code parse the list properly
            sendRaw("CAP REQ :${wanted.joinToString(" ")}")
            // After ACK we continue registration
            scope.launch {
                delay(200)
                if (currentProfile?.saslUser != null) {
                    sendRaw("CAP REQ :sasl")
                    // SASL will be handled next
                } else {
                    finishRegistration()
                }
            }
        }
        if (raw.contains("ACK") && raw.contains("sasl")) {
            saslInProgress = true
            sendRaw("AUTHENTICATE PLAIN")
        }
    }

    private fun handleSasl(raw: String) {
        if (raw.startsWith("AUTHENTICATE +")) {
            val user = currentProfile?.saslUser ?: return
            val pass = currentProfile?.saslPass ?: return
            // PLAIN: \0 user \0 pass  → base64
            val payload = "\u0000$user\u0000$pass"
            val b64 = android.util.Base64.encodeToString(
                payload.toByteArray(Charsets.UTF_8),
                android.util.Base64.NO_WRAP
            )
            sendRaw("AUTHENTICATE $b64")
        }
        if (raw.contains("903") || raw.contains("904") || raw.contains("905")) {
            // Success or failure
            saslInProgress = false
            finishRegistration()
        }
    }

    private fun finishRegistration() {
        sendRaw("CAP END")
        val p = currentProfile ?: return
        if (p.password != null) sendRaw("PASS ${p.password}")
        sendRaw("NICK ${p.nick}")
        sendRaw("USER ${p.user} 0 * :${p.realName}")
        _state.value = _state.value.copy(status = ConnStatus.REGISTERING)
    }

    private fun emitMessage(p: Parsed) {
        val msg = IrcMessage(
            id = UUID.randomUUID().toString(),
            bufferId = p.params.getOrNull(0) ?: "",
            networkId = currentProfile?.id ?: "",
            timestamp = System.currentTimeMillis(),
            sender = p.nick ?: p.prefix ?: "",
            target = p.params.getOrNull(0) ?: "",
            text = p.params.getOrNull(1) ?: "",
            type = if (p.command == "NOTICE") MessageType.NOTICE else MessageType.PRIVMSG,
            isSelf = p.nick == currentProfile?.nick
        )
        scope.launch { _messages.emit(msg) }
    }

    private fun emitSystem(p: Parsed) {
        val text = when (p.command) {
            "JOIN" -> "${p.nick} joined"
            "PART" -> "${p.nick} left (${p.params.getOrNull(1) ?: ""})"
            "QUIT" -> "${p.nick} quit (${p.params.getOrNull(0) ?: ""})"
            else -> p.raw
        }
        val msg = IrcMessage(
            id = UUID.randomUUID().toString(),
            bufferId = p.params.getOrNull(0) ?: p.nick ?: "",
            networkId = currentProfile?.id ?: "",
            timestamp = System.currentTimeMillis(),
            sender = "",
            target = "",
            text = text,
            type = MessageType.SYSTEM
        )
        scope.launch { _messages.emit(msg) }
    }

    fun sendRaw(line: String) {
        scope.launch(Dispatchers.IO) {
            try {
                writer?.apply {
                    write(line)
                    write("\r\n")
                    flush()
                }
                Timber.d(">> %s", line)
            } catch (e: Exception) {
                Timber.e(e, "Send failed")
            }
        }
    }

    fun sendPrivmsg(target: String, text: String) {
        sendRaw("PRIVMSG $target :$text")
        // Echo locally
        val msg = IrcMessage(
            id = UUID.randomUUID().toString(),
            bufferId = target,
            networkId = currentProfile?.id ?: "",
            timestamp = System.currentTimeMillis(),
            sender = currentProfile?.nick ?: "",
            target = target,
            text = text,
            type = MessageType.PRIVMSG,
            isSelf = true
        )
        scope.launch { _messages.emit(msg) }
    }

    fun join(channel: String) = sendRaw("JOIN $channel")
    fun part(channel: String, reason: String = "") = sendRaw("PART $channel :$reason")
    fun quit(reason: String = "ArchIRC") = sendRaw("QUIT :$reason")

    fun disconnect() {
        running.set(false)
        readerJob?.cancel()
        pingJob?.cancel()
        try {
            writer?.close()
            socket?.close()
        } catch (_: Exception) {}
        socket = null
        writer = null
        _state.value = _state.value.copy(status = ConnStatus.DISCONNECTED)
    }

    private fun scheduleReconnect() {
        // Simple backoff stub — real implementation would use exponential + jitter
        scope.launch {
            delay(5_000)
            currentProfile?.let { if (running.get().not()) connect(it) }
        }
    }

    // Extremely minimal IRC line parser
    private data class Parsed(
        val raw: String,
        val prefix: String?,
        val nick: String?,
        val command: String,
        val params: List<String>
    )

    private fun parseLine(raw: String): Parsed? {
        if (raw.isBlank()) return null
        var rest = raw
        var prefix: String? = null
        if (rest.startsWith(":")) {
            val space = rest.indexOf(' ')
            if (space == -1) return null
            prefix = rest.substring(1, space)
            rest = rest.substring(space + 1)
        }
        val parts = rest.split(" ", limit = 2)
        val command = parts[0].uppercase()
        val paramStr = parts.getOrNull(1) ?: ""
        val params = mutableListOf<String>()
        var i = 0
        while (i < paramStr.length) {
            if (paramStr[i] == ':') {
                params.add(paramStr.substring(i + 1))
                break
            }
            val next = paramStr.indexOf(' ', i)
            if (next == -1) {
                params.add(paramStr.substring(i))
                break
            }
            params.add(paramStr.substring(i, next))
            i = next + 1
        }
        val nick = prefix?.substringBefore('!')?.substringBefore('@')
        return Parsed(raw, prefix, nick, command, params)
    }
}

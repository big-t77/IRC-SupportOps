package com.archirc.client.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import com.archirc.client.ui.theme.ArchBlue

data class ChatLine(
    val time: String,
    val nick: String?,
    val text: String,
    val isAction: Boolean = false,
    val isSelf: Boolean = false
)

@Composable
fun ChannelsScreen() {
    val lines = remember {
        listOf(
            ChatLine("20:45", "Thomas", "This app is awesome! 👍", isSelf = true),
            ChatLine("20:46", "OpHawk", "Finally a real IRC client on Android."),
            ChatLine("20:46", "LinuxDork", "Nice work!"),
            ChatLine("20:47", "DevNull", "Light and dark mode works great."),
            ChatLine("20:47", null, "DevNull is now away: AFK", isAction = true),
        )
    }
    var draft by remember { mutableStateOf("@Th") }
    var showSuggest by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize()) {
        // Channel header
        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "#linux",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
                Text(
                    "42 users",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = {}) {
                Icon(Icons.Outlined.People, contentDescription = "Users")
            }
            IconButton(onClick = {}) {
                Icon(Icons.Outlined.MoreVert, contentDescription = "More")
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

        // Messages
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            reverseLayout = false
        ) {
            items(lines) { line ->
                MessageRow(line)
            }
        }

        // Nick autocomplete (matches mockup popup)
        if (showSuggest && draft.startsWith("@")) {
            Surface(
                modifier = Modifier
                    .padding(horizontal = 12.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                tonalElevation = 4.dp,
                shadowElevation = 6.dp
            ) {
                Column {
                    listOf(
                        "Thomas" to true,
                        "TheSysOp" to true,
                        "TheLinuxDork" to false,
                        "ThunderBolt" to false
                    ).forEach { (nick, op) ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (op) {
                                Text("👑 ", fontSize = 14.sp)
                            } else {
                                Text("👤 ", fontSize = 14.sp)
                            }
                            Text(nick, fontWeight = if (op) FontWeight.SemiBold else FontWeight.Normal)
                            if (op) {
                                Text(
                                    "  (Operator)",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        // Input bar
        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) {
                Icon(Icons.Outlined.EmojiEmotions, contentDescription = "Emoji")
            }
            BasicTextField(
                value = draft,
                onValueChange = {
                    draft = it
                    showSuggest = it.startsWith("@")
                },
                modifier = Modifier
                    .weight(1f)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                textStyle = LocalTextStyle.current.copy(
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 15.sp
                ),
                cursorBrush = SolidColor(ArchBlue),
                singleLine = true
            )
            Spacer(Modifier.width(6.dp))
            FilledIconButton(
                onClick = { /* send */ },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = ArchBlue)
            ) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}

@Composable
private fun MessageRow(line: ChatLine) {
    if (line.isAction) {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)) {
                    append("[${line.time}] * ")
                }
                withStyle(SpanStyle(color = MaterialTheme.colorScheme.onSurfaceVariant, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) {
                    append(line.text)
                }
            },
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp
        )
        return
    }
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)) {
                append("[${line.time}] ")
            }
            withStyle(
                SpanStyle(
                    color = if (line.isSelf) ArchBlue else ColorNick(line.nick ?: ""),
                    fontWeight = FontWeight.SemiBold
                )
            ) {
                append("<${line.nick}> ")
            }
            withStyle(SpanStyle(color = MaterialTheme.colorScheme.onSurface)) {
                append(line.text)
            }
        },
        fontFamily = FontFamily.Monospace,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
}

private fun ColorNick(nick: String): androidx.compose.ui.graphics.Color {
    val palette = listOf(
        androidx.compose.ui.graphics.Color(0xFFE06C75),
        androidx.compose.ui.graphics.Color(0xFF98C379),
        androidx.compose.ui.graphics.Color(0xFFE5C07B),
        androidx.compose.ui.graphics.Color(0xFF61AFEF),
        androidx.compose.ui.graphics.Color(0xFFC678DD),
        androidx.compose.ui.graphics.Color(0xFF56B6C2),
    )
    return palette[kotlin.math.abs(nick.hashCode()) % palette.size]
}

package com.archirc.client.data

import kotlinx.serialization.Serializable

@Serializable
data class NetworkProfile(
    val id: String,
    val name: String,
    val host: String,
    val port: Int = 6697,
    val useTls: Boolean = true,
    val nick: String,
    val user: String = "archirc",
    val realName: String = "ArchIRC User",
    val password: String? = null,          // server password
    val saslUser: String? = null,
    val saslPass: String? = null,
    val isBouncer: Boolean = false,
    val bouncerType: BouncerType = BouncerType.NONE,
    val autoConnect: Boolean = false,
    val channels: List<String> = emptyList()
)

enum class BouncerType {
    NONE, ZNC, SOJU, OTHER
}

@Serializable
data class Buffer(
    val id: String,                 // "#channel" or "nick" for query
    val networkId: String,
    val name: String,
    val isChannel: Boolean,
    val topic: String = "",
    val unread: Int = 0,
    val highlights: Int = 0,
    val lastActivity: Long = 0L
)

@Serializable
data class IrcMessage(
    val id: String,
    val bufferId: String,
    val networkId: String,
    val timestamp: Long,
    val sender: String,
    val target: String,
    val text: String,
    val type: MessageType = MessageType.PRIVMSG,
    val tags: Map<String, String> = emptyMap(),
    val isSelf: Boolean = false
)

enum class MessageType {
    PRIVMSG, NOTICE, ACTION, JOIN, PART, QUIT, MODE, TOPIC, NICK, SYSTEM, ERROR
}

data class ConnectionState(
    val networkId: String,
    val status: ConnStatus = ConnStatus.DISCONNECTED,
    val lastError: String? = null,
    val serverName: String? = null,
    val myNick: String? = null,
    val capabilities: Set<String> = emptySet()
)

enum class ConnStatus {
    DISCONNECTED, CONNECTING, REGISTERING, CONNECTED, RECONNECTING
}

/** Built-in quick-add directory (same as the web patch) */
object NetworkDirectory {
    val presets = listOf(
        NetworkProfile("libera", "Libera.Chat", "irc.libera.chat", 6697, true, "YourNick"),
        NetworkProfile("oftc", "OFTC", "irc.oftc.net", 6697, true, "YourNick"),
        NetworkProfile("efnet", "EFnet", "irc.efnet.org", 6697, true, "YourNick"),
        NetworkProfile("ircnet", "IRCnet", "open.ircnet.net", 6697, true, "YourNick"),
        NetworkProfile("rizon", "Rizon", "irc.rizon.net", 6697, true, "YourNick"),
        NetworkProfile("dalnet", "DALnet", "irc.dal.net", 6697, true, "YourNick"),
        NetworkProfile("quakenet", "QuakeNet", "irc.quakenet.org", 6697, true, "YourNick"),
        NetworkProfile("hackint", "hackint", "irc.hackint.org", 6697, true, "YourNick"),
        NetworkProfile("esper", "EsperNet", "irc.esper.net", 6697, true, "YourNick"),
        NetworkProfile("snoonet", "Snoonet", "irc.snoonet.org", 6697, true, "YourNick")
    )
}

package com.archirc.client.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import timber.log.Timber

/**
 * Optional auto-restart of the connection service after boot.
 * In a full implementation this would read "autoConnect" profiles from DataStore
 * and start the service only if the user has enabled it.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            Timber.i("Boot completed – auto-connect logic would live here")
            // Example:
            // context.startForegroundService(Intent(context, IrcConnectionService::class.java))
        }
    }
}

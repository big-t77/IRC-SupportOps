package com.archirc.client.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.archirc.client.R
import com.archirc.client.core.IrcEngine
import com.archirc.client.data.NetworkProfile
import com.archirc.client.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import timber.log.Timber

/**
 * Foreground Service that owns the IrcEngine.
 * Holds a partial wake lock so the socket stays alive in doze.
 *
 * Bouncers work here the same way as direct servers:
 * just point the NetworkProfile at the bouncer host:port with TLS.
 * No extra SSH tunnel is required if the bouncer is publicly reachable.
 */
class IrcConnectionService : Service() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private lateinit var engine: IrcEngine
    private var wakeLock: PowerManager.WakeLock? = null

    private val binder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getEngine(): IrcEngine = engine
        fun getService(): IrcConnectionService = this@IrcConnectionService
    }

    override fun onCreate() {
        super.onCreate()
        engine = IrcEngine(scope)
        createNotificationChannel()
        acquireWakeLock()
        Timber.i("IrcConnectionService created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Connecting…"))
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun connect(profile: NetworkProfile) {
        scope.launchSafe {
            engine.connect(profile)
            updateNotification("Connected to ${profile.name}")
        }
    }

    fun disconnect() {
        engine.disconnect()
        updateNotification("Disconnected")
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "ArchIRC::ConnectionWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L) // 10 h max, renew as needed
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent IRC connection status"
            setShowBadge(false)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.service_notification_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // replace with real icon later
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        engine.disconnect()
        wakeLock?.let { if (it.isHeld) it.release() }
        scope.cancel()
        Timber.i("IrcConnectionService destroyed")
        super.onDestroy()
    }

    private fun CoroutineScope.launchSafe(block: suspend CoroutineScope.() -> Unit) {
        this.launch {
            try {
                block()
            } catch (e: Exception) {
                Timber.e(e)
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "irc_status"
        const val NOTIFICATION_ID = 42
    }
}

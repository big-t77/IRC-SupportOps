package com.archirc.client.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ToolsScreen() {
    var host by remember { mutableStateOf("irc.libera.chat") }
    var port by remember { mutableStateOf("6697") }
    var nick by remember { mutableStateOf("") }
    var saslUser by remember { mutableStateOf("") }
    var tls by remember { mutableStateOf(true) }
    var isBouncer by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Connection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Host") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Port") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = nick, onValueChange = { nick = it }, label = { Text("Nick") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = saslUser, onValueChange = { saslUser = it }, label = { Text("SASL / NickServ user") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TLS", modifier = Modifier.weight(1f))
            Switch(checked = tls, onCheckedChange = { tls = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("This is a bouncer")
                Text("ZNC / soju — direct TLS, no SSH tunnel", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = isBouncer, onCheckedChange = { isBouncer = it })
        }

        Button(onClick = { /* connect via service */ }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.Link, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Connect")
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Text("Operator tools", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text("Available when you hold +o in a channel.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        listOf(
            Icons.Outlined.PersonRemove to "Kick",
            Icons.Outlined.Block to "Ban",
            Icons.Outlined.Topic to "Set topic",
            Icons.Outlined.Lock to "Modes (+m / +i / +s)"
        ).forEach { (icon, label) ->
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Icon(icon, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(label)
            }
        }
    }
}

package com.archirc.client.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun UsersScreen() {
    val users = listOf(
        "Thomas" to "@",
        "TheSysOp" to "@",
        "OpHawk" to "%",
        "TheLinuxDork" to "+",
        "LinuxDork" to "",
        "ThunderBolt" to "",
        "DevNull" to "",
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Users in #linux", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(users) { (nick, prefix) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Person, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "$prefix$nick",
                        fontSize = 15.sp,
                        fontWeight = if (prefix == "@") FontWeight.SemiBold else FontWeight.Normal
                    )
                    if (prefix == "@") {
                        Spacer(Modifier.width(8.dp))
                        Text("Operator", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

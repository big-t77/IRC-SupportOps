package com.archirc.client.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.archirc.client.ui.screens.MainShell
import com.archirc.client.ui.theme.ArchIrcTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var dark by remember { mutableStateOf<Boolean?>(null) }
            val systemDark = isSystemInDarkTheme()
            val useDark = dark ?: systemDark

            ArchIrcTheme(darkTheme = useDark) {
                Scaffold(modifier = Modifier.fillMaxSize()) { inner ->
                    MainShell(
                        modifier = Modifier.padding(inner),
                        darkTheme = useDark,
                        onToggleTheme = { dark = !useDark }
                    )
                }
            }
        }
    }
}

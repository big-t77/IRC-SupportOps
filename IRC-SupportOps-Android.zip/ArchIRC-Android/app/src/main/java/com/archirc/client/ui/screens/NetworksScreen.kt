package com.archirc.client.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archirc.client.data.NetworkDirectory
import com.archirc.client.data.NetworkProfile
import com.archirc.client.ui.theme.ArchBlue

data class NetworkRow(
    val profile: NetworkProfile,
    val accent: Color,
    val mark: String,
    val online: Boolean = true
)

@Composable
fun NetworksScreen() {
    // Preloaded directory from the mockup
    val rows = remember {
        listOf(
            NetworkRow(NetworkDirectory.presets[0], Color(0xFF7B68EE), "🔥"), // Libera
            NetworkRow(NetworkDirectory.presets[1], Color(0xFF2E8B57), "O"),  // OFTC
            NetworkRow(NetworkDirectory.presets[2], Color(0xFFE67E22), "EF"), // EFnet
            NetworkRow(NetworkDirectory.presets[3], Color(0xFF3498DB), "IRC"), // IRCnet
            NetworkRow(NetworkDirectory.presets[4], Color(0xFFE74C3C), "R"),  // Rizon
            NetworkRow(NetworkDirectory.presets[5], Color(0xFF9B59B6), "D"),  // DALnet
            NetworkRow(NetworkDirectory.presets[6], Color(0xFFF1C40F), "Q"),  // QuakeNet
            NetworkRow(NetworkDirectory.presets[7], Color(0xFF1ABC9C), "h"),  // hackint
        )
    }
    var selectedId by remember { mutableStateOf(rows.first().profile.id) }

    Column(Modifier.fillMaxSize()) {
        // Section header
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Networks",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { /* refresh */ }) {
                Icon(Icons.Outlined.Refresh, contentDescription = "Refresh", tint = ArchBlue)
            }
            IconButton(onClick = { /* add custom */ }) {
                Icon(Icons.Outlined.Add, contentDescription = "Add network", tint = ArchBlue)
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(rows, key = { it.profile.id }) { row ->
                NetworkCard(
                    row = row,
                    selected = selectedId == row.profile.id,
                    onClick = { selectedId = row.profile.id }
                )
            }
            item {
                Spacer(Modifier.height(24.dp))
                Text(
                    "Tap a network, then configure nick / SASL / channels in Tools → Connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = PaddingValues(horizontal = 8.dp).let { Modifier.padding(it) }
                )
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun NetworkCard(
    row: NetworkRow,
    selected: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    val bg = if (selected) ArchBlue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
    val border = if (selected) ArchBlue.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)

    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Status dot
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (row.online) Color(0xFF2ECC71) else Color(0xFF95A5A6))
        )
        Spacer(Modifier.width(10.dp))

        // Network mark badge
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(row.accent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                row.mark,
                color = row.accent,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
        Spacer(Modifier.width(12.dp))

        Column(Modifier.weight(1f)) {
            Text(
                row.profile.name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                "${row.profile.host} · ${row.profile.port} (TLS)",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (selected) {
            Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = ArchBlue)
        }
    }
}

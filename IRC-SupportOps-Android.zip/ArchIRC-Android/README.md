# IRC SupportOps (ArchIRC)

Native Android IRC client — design target matches the light/dark mockup:

- Networks list with status + TLS
- Channels buffer + nick autocomplete
- Users list with operator marks
- Tools: host/port/TLS/SASL/bouncer + operator actions
- Foreground service + wake lock for persistent TLS
- Arch Linux inspired theme (`#1793D1` on deep dark / clean light)

## Build APK (no local Android Studio required)

### Option A — GitHub Actions
1. Push this folder to a GitHub repo
2. Add `.github/workflows/build.yml` (see below)
3. Actions → download `app-debug.apk`

### Option B — Android Studio Cloud
Open the project in [Android Studio Cloud](https://developer.android.com/studio/preview/android-studio-cloud) → Build → APK

### Option C — Local
```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Bouncers
ZNC / soju work over normal TLS on the public port. No SSH side tunnel required.

## Status
UI shell matches the mockup layout. Socket engine + foreground service are present; wire Connect button → `IrcConnectionService` next.
